@if($url=='clients')
  <link rel="stylesheet" type="text/css" href="{{asset('DataTables/datatables.css')}}">
@endif
  