Hello <strong>{{ $name }}</strong>,
<p>{{$body}}</p>

<a href="{{$url}}">click me to verify</a>

<p>Or</p>

<p>{{$url}}</p>
