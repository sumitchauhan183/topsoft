Hello <strong>{{ $name }}</strong>,
<p>{{$body}}</p>

<b>Thanks for joining us.</b>