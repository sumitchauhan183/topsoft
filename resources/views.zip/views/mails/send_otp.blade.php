Hello <strong>{{ $name }}</strong>,
<p>{{$body}}</p>
